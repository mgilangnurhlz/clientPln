export { default } from './label';
